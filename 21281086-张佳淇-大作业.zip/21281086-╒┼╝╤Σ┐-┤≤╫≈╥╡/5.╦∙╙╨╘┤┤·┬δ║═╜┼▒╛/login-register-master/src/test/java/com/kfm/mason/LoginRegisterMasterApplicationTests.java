package com.manage.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginRegisterMasterApplicationTests {

    @Test
    void contextLoads() {
    }

}
