package com.manage.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginRegisterMasterApplication {

    public static void main(String[] args) {
        SpringApplication.run(LoginRegisterMasterApplication.class, args);
    }

}
